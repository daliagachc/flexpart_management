# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.4.0
#   kernelspec:
#     display_name: Python 3
#     language: python
#     name: python3
# ---

# %% pycharm={"is_executing": false} jupyter={"outputs_hidden": true}
import xarray as xr

# %% pycharm={"name": "#%%\n", "is_executing": false} jupyter={"outputs_hidden": false}
# ! pwd
# %%


